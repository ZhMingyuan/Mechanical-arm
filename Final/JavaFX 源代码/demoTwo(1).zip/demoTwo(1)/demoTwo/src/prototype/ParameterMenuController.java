package prototype;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

public
class ParameterMenuController {

    @FXML
    private Button FileButton;

    @FXML
    private VBox MenuVBox;

    @FXML
    private AnchorPane MenuAnchorPane;

    public
    void onFileButton() {
        File directory = new File("");
        try {
            String cmdDir[] = {"explorer.exe", directory.getCanonicalPath() + "\\resource"};
            Runtime.getRuntime().exec(cmdDir);
            Stage menuInterface = (Stage) MenuAnchorPane.getScene().getWindow();
            menuInterface.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
