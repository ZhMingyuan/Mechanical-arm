package prototype;

import arduino.Arduino;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;


public
class Main extends Application {
    AtomicBoolean result = new AtomicBoolean(false);
    CountDownLatch countDownLatch = new CountDownLatch(1);
    Arduino arduino = new Arduino("COM4", 9600);

    public
    void arduinoConnection() throws InterruptedException {
        Task<Void> selfInspection = new Task<Void>() {
            @Override
            protected
            Void call() throws Exception {
                arduino.openConnection();
                Thread.sleep(1000);
                String arduinoRead = null;
                arduino.serialWrite("Z");
                do {
                    arduinoRead = arduino.serialRead();
                    System.out.println(arduinoRead);
                } while (!arduinoRead.contains("S"));

                if (arduinoRead.contains("S")) {//检测arduino自检是否完成
                    result.set(true);
                    System.out.println(result.get() + " " + 1);
                }
                return null;
            }
        };

        Thread selfInspectionThread = new Thread(selfInspection);
        selfInspectionThread.start();
    }


    @Override
    public
    void start(Stage primaryStage) throws Exception {

        Parent launchPage = FXMLLoader.load(getClass().getResource("LaunchPage.fxml"));
        primaryStage.setScene(new Scene(launchPage));
        primaryStage.getIcons().add(new Image(Main.class.getResourceAsStream("机械设备.png")));
        primaryStage.setTitle("机械臂操作软件");

        primaryStage.show();//设置启动页面

        arduinoConnection();

        Platform.runLater(()->{
           while (true){
               System.out.println(result.get() + " " + 2);
               if (result.get() == true) {//判断自检是否完成
                   Parent mainInterfaceLoader = null;
                   try {
                       mainInterfaceLoader = FXMLLoader.load(Main.class.getResource("main-interface.fxml"));
                   } catch (IOException e) {
                       e.printStackTrace();
                   }
                   Stage mainInterface = new Stage();
                   mainInterface.setScene(new Scene(mainInterfaceLoader));
                   mainInterface.setTitle("机械臂操作软件");
                   mainInterface.getIcons().add(new Image(Main.class.getResourceAsStream("机械设备.png")));
                   mainInterface.show();
                   primaryStage.close();
                   arduino.closeConnection();
                   break;
               }
           }
        });

    }

    public static
    void main(String[] args) {
        launch(args);
    }
}
