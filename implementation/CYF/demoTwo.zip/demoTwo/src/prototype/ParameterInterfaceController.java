package prototype;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class ParameterInterfaceController {

    @FXML
    private Label degreeOne;

    @FXML
    private Label currentDataThree;

    @FXML
    private Label currentTwo;

    @FXML
    private Label currentFive;

    @FXML
    private Label motorOne;

    @FXML
    private Label degreeDataTwo;

    @FXML
    private Label voltageThree;

    @FXML
    private Label voltageDataFive;

    @FXML
    private Label degreeFive;

    @FXML
    private Label currentDataTwo;

    @FXML
    private Label currentThree;

    @FXML
    private Label degreeDataFour;

    @FXML
    private Label voltageDataTwo;

    @FXML
    private Label degreeFour;

    @FXML
    private Label degreeSix;

    @FXML
    private Label degreeDataThree;

    @FXML
    private Label motorThree;

    @FXML
    private Label voltageDataOne;

    @FXML
    private Label voltageOne;

    @FXML
    private Label voltageDataFour;

    @FXML
    private Label motorFour;

    @FXML
    private Label voltageDataThree;

    @FXML
    private Label voltageDataSix;

    @FXML
    private Label degreeTwo;

    @FXML
    private Label motorSix;

    @FXML
    private Label voltageSix;

    @FXML
    private Label currentDataSix;

    @FXML
    private HBox motorTwo;

    @FXML
    private Label degreeDataOne;

    @FXML
    private Label currentDataOne;

    @FXML
    private Label currentDataFour;

    @FXML
    private Label voltageFive;

    @FXML
    private Label motorFive;

    @FXML
    private Label degreeThree;

    @FXML
    private Label currentFour;

    @FXML
    private Label voltageTwo;

    @FXML
    private Label currentOne;

    @FXML
    private Label currentDataFive;

    @FXML
    private Label voltageFour;

    @FXML
    private Label degreeDataFive;

    @FXML
    private Label degreeDataSix;

    @FXML
    private Label currentSix;



}

