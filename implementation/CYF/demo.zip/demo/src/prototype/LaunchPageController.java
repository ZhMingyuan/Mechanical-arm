package prototype;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class LaunchPageController {

    @FXML
    private AnchorPane LaunchPageAnchorPane;

    @FXML
    private ImageView Icon;

    @FXML
    private Label LaunchLabel;






}
